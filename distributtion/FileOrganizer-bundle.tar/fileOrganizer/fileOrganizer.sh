#!/bin/sh
java -jar ./FileOrganizer.jar